/*
 * compiler.h
 * Copyright 2019 Peter Jones <pjones@redhat.com>
 */

#ifndef LIBDPE_COMPILER_H_
#define LIBDPE_COMPILER_H_

#include "../src/compiler.h"

#endif /* !LIBDPE_COMPILER_H_ */
// vim:fenc=utf-8:tw=75:et
