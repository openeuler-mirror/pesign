/*
 * Copyright 2012 Red Hat, Inc.
 * All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; version 2 of the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * Author(s): Peter Jones <pjones@redhat.com>
 */
#ifndef PASSWORD_H
#define PASSWORD_H

extern char *SECU_GetModulePassword(PK11SlotInfo *slot, PRBool retry, void *arg);
extern char *get_password_passthrough(PK11SlotInfo *slot, PRBool retry, void *arg);
extern char *get_password_fail(PK11SlotInfo *slot, PRBool retry, void *arg);
extern char *readpw(PK11SlotInfo *slot, PRBool retry, void *arg);

#endif /* PASSWORD_H */
