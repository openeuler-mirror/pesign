// SPDX-License-Identifier: GPLv2
/*
 * pe_readall.c - not implemented
 * Copyright Peter Jones <pjones@redhat.com>
 * Copyright Red Hat, Inc.
 */
#include "libdpe_priv.h"

char *
__libpe_readall(Pe *pe UNUSED)
{
	return NULL;
}
