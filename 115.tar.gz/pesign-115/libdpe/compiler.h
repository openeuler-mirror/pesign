// SPDX-License-Identifier: GPLv2
/*
 * compiler.h - borrow the compiler.h from pesign
 * Copyright Peter Jones <pjones@redhat.com>
 */
#ifndef LIBDPE_COMPILER_H_
#define LIBDPE_COMPILER_H_

#include "../src/compiler.h"

#endif /* !LIBDPE_COMPILER_H_ */
// vim:fenc=utf-8:tw=75:et
